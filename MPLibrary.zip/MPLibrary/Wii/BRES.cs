﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MPLibrary.Wii
{
    //Todo link brawl box libraries and create classes to represent the space info
    //Spaces use bones + user data for MP9
    public class BRES
    {

    }
}
