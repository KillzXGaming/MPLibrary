﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Toolbox.Core;

namespace MPLibrary
{
    public class Plugin : IPlugin
    {
        public string Name => "Mario Party Library";
    }
}
