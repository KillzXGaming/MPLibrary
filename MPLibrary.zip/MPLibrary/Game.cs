﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MPLibrary
{
    public enum GameVersion
    {
        MP1,
        MP2,
        MP3,
        MP4,
        MP5,
        MP6,
        MP7,
        MP8,
        MP9,
        MP10,
        MPDS,
        SMP,
    }
}
