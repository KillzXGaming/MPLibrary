﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MPLibrary.GCN
{
    public class HSF_ModelImporter
    {
        public class Mesh
        {

        }

        public void Import()
        {

        }
    }
}
