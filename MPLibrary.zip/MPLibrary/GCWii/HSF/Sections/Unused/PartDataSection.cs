﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Toolbox.Core.IO;
using System.Runtime.InteropServices;

namespace MPLibrary.GCN
{
    public class PartDataSection : HSFSection
    {
        public override void Read(FileReader reader, HsfFile header)
        {

        }

        public override void Write(FileWriter writer, HsfFile header)
        {
        }
    }

}
