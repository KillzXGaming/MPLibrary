﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Toolbox.Core.IO;

namespace MPLibrary.DS
{
    public class AnimationBlock : IBlockSection
    {
        public void Read(HsdfFile header, FileReader reader)
        {

        }

        public void Write(HsdfFile header, FileWriter writer)
        {

        }
    }
}
